//
//  main.h
//  CLinkedList
//
//  Created by Michael Muggler on 2/18/13.
//  Copyright (c) 2013 Michael Muggler. All rights reserved.
//

#include <stdio.h>
#include "linkedlist.h"
